import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-response-reset',
  templateUrl: './response-reset.component.html',
  styleUrls: ['./response-reset.component.css']
})
export class ResponseResetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
